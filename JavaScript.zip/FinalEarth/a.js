
function ar(){
    return b;
}

console.log('1');
console.log(1);