
function good(){
    let a = {
        name: 'earth',
        age: 18,
        detail:'good'
    };
    return a;
}

console.log(good());